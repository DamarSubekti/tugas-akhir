<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\CartController;
use App\Http\Controllers\SearchController;
use App\Http\Controllers\MenuController;
use App\Http\Controllers\AuthController;
use App\Models\User;
use App\Http\Controllers\LogoutController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', [DashboardController::class, 'index']);
Route::post('/add-to-cart', [CartController::class, 'addToCart'])->name('cart.add');
Route::post('/add-to-cart', [CartController::class, 'addToCart'])->middleware('auth');
Route::get('/cart', [CartController::class, 'showCart'])->name('cart.show');
Route::post('/submit-order', [CartController::class, 'submitOrder'])->name('submit.order');
Route::get('/order-success/{orderId}/{totalAmount}', [CartController::class, 'orderSuccess'])->name('order.success');
Route::get('/search', [SearchController::class, 'index'])->name('search');
Route::get('/menu', [MenuController::class, 'index'])->name('menu');
Route::get('/login', [AuthController::class, 'showLoginForm'])->name('login');
Route::post('/login', [AuthController::class, 'login'])->name('login.post');
Route::get('/register', [AuthController::class, 'showRegistrationForm'])->name('register');
Route::post('/register', [AuthController::class, 'register'])->name('register.post');
Route::post('/logout', [LogoutController::class, 'logout'])->name('logout');
