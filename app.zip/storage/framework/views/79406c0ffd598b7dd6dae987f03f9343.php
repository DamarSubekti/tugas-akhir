<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,400;0,700;1,700&display=swap" rel="stylesheet">
    <!-- Include SweetAlert2 library -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>

    <!-- Feathers Icons -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- My Style -->
    <link rel="stylesheet" href="css/style.css" />
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('img/header-bg.jpg');
            background-size: cover;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            color: #111111;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
            color: #111111;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #111111;
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #ff6b6b;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #ff4f4f;
        }
    </style>
</head>
<body>
     <!-- Navbar Start-->
     <nav class="navbar">
        <a href="#" class="navbar-logo">ngopi<span>terus.</span></a>

        <div class="navbar-nav">
          <a href="/#home">Home</a>
          <a href="/#about">Tentang Kami</a>
          <a href="/#menu">Menu</a>
          <a href="/#contact">Kontak</a>
        </div>

        <div class="navbar-extra">
          <a href="<?php echo e(route('search')); ?>" id="search-button"><i data-feather="search"></i></a>
          <a href="<?php echo e(route('cart.show')); ?>" id="shopping-cart"><i data-feather="shopping-cart"></i></a>
          <a href="#" id="hamburger-menu"><i data-feather="menu"></i></a>
        </div>
    </nav>


    <section class="register id="register">
<div class="container">
    <h2>Register</h2>

    <?php if(session('success')): ?>
        <p style="color: green;"><?php echo e(session('success')); ?></p>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('register.post')); ?>">
        <?php echo csrf_field(); ?>

        <label for="name">Name</label>
        <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>" required>

        <label for="email">Email</label>
        <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required>

        <label for="password">Password</label>
        <input type="password" name="password" id="password" required>

        <label for="password_confirmation">Confirm Password</label>
        <input type="password" name="password_confirmation" id="password_confirmation" required>

        <button type="submit">Register</button>

        <p>Do have an account? <a href="<?php echo e(route('login')); ?>">Login here</a>.</p>
    </form>
</div>
    </section>
</body>
</html>
<?php /**PATH C:\Users\Katon\Documents\katon\semester 4\web\example-app\example-app\example-app\resources\views/auth/register.blade.php ENDPATH**/ ?>