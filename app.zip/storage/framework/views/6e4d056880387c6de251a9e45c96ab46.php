<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kopi Terus</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,400;0,700;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Feathers Icons -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- My Style -->
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <!-- Navbar Start-->
    <nav class="navbar">
      <a href="#" class="navbar-logo">ngopi<span>terus.</span></a>

      <div class="navbar-nav">
        <a href="/#home">Home</a>
        <a href="/#about">Tentang Kami</a>
        <a href="/#menu">Menu</a>
        <a href="/#contact">Kontak</a>
      </div>

      <div class="navbar-extra">
        <a href="<?php echo e(route('search')); ?>" id="search-button"><i data-feather="search"></i></a>
        <a href="<?php echo e(route('cart.show')); ?>" id="shopping-cart"><i data-feather="shopping-cart"></i></a>
        <a href="#" id="hamburger-menu"><i data-feather="menu"></i></a>
      </div>

      <!-- Search Form start -->
      <div class="search-form">
        <input type="search" id="search-box" placeholder="search here..." />
        <label for="search-box"><i data-feather="search"></i></label>
      </div>
      <!-- Search Form end -->
    </nav>
    <!-- Navbar End-->

    <!-- About Section Start -->
    <section id="about" class="about">
      <h2><span>Cart</h2>
      <!-- Add a form to submit the order data -->
      <form action="<?php echo e(route('submit.order')); ?>" method="post">
        <?php echo csrf_field(); ?> <!-- Add the CSRF token -->
        <table class="table custom-table">
          <thead>
            <tr>
              <td>Gambar</td>
              <th>Name</th>
              <th>Price</th>
              <th>Quantity</th>
            </tr>
          </thead>
          <tbody>
            <?php if(count($cart) > 0): ?>
              <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productId => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td style="width: 150px"><img src="img/<?php echo e($product['gambar']); ?>" alt="<?php echo e($product['nama']); ?>" style="width: 100%;" class="menu-card-img" /></td>
                  <td><?php echo e($product['nama']); ?></td>
                  <td>IDR <?php echo e($product['harga']); ?></td>
                  <td><?php echo e($product['jumlah']); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="4" style="text-align: center;">Your cart is empty.</td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
        <?php if(count($cart) > 0): ?>
          <center>
            <table border="none" style="margin-top: 15px;">
              <input type="hidden" name="id" value="<?php echo e($product['id']); ?>">
              <tr>
                <td>Nama</td>
                <td>:</td>
                <td><input type="text" id="name" name="namaOrang" class="form-control" style="padding: 10px; width: 300px; margin: 10px; border-radius: 5px;" required></td>
              </tr>
              <tr>
                <td>No Telepon</td>
                <td>:</td>
                <td><input type="text" id="notelp" name="notelp" class="form-control" style="padding: 10px; width: 300px; margin: 10px; border-radius: 5px" required></td>
              </tr>
            </table>
            <button type="submit" class="btn" style="padding: 5px; border-radius: 5px; width: 100px; margin-top: 20px; background-color: #2E8B57; color: white;">Submit Order</button>
          </center>
        <?php endif; ?>
      </form>
    </section>


    <!-- Footer Section start -->
    <footer>
      <div class="socials">
        <a href="#"><i data-feather="instagram"></i></a>
        <a href="#"><i data-feather="twitter"></i></a>
        <a href="#"><i data-feather="facebook"></i></a>
      </div>

      <div class="links">
        <a href="#">Home</a>
        <a href="#about">Tentang Kami</a>
        <a href="#menu">Menu</a>
        <a href="#contact">Kontak</a>
      </div>

      <div class="credit">
        <p>Created by <a href="">Boys.</a>. | &copy; 2023.</p>
      </div>
    </footer>
    <!-- Footer Section end -->

    <!-- Feather Icons -->
    <script>
      feather.replace();
    </script>

    <!-- My javascirpt -->
    <script src="js/script.js"></script>
  </body>
</html><?php /**PATH D:\Joki\example-app\resources\views/cart.blade.php ENDPATH**/ ?>