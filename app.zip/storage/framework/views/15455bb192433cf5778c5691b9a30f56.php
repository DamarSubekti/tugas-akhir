<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kopi Terus</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,400;0,700;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Feathers Icons -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- My Style -->
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>" />
  </head>
  <body>
    <!-- Navbar Start-->
    <nav class="navbar">
      <a href="#" class="navbar-logo">ngopi<span>terus.</span></a>

      <div class="navbar-nav">
        <a href="/#home">Home</a>
        <a href="/#about">Tentang Kami</a>
        <a href="/#menu">Menu</a>
        <a href="/#contact">Kontak</a>
      </div>

      <div class="navbar-extra">
        <a href="<?php echo e(route('search')); ?>" id="search-button"><i data-feather="search"></i></a>
        <a href="<?php echo e(route('cart.show')); ?>" id="shopping-cart"><i data-feather="shopping-cart"></i></a>
        <a href="#" id="hamburger-menu"><i data-feather="menu"></i></a>
      </div>

      <!-- Search Form start -->
      <div class="search-form">
        <input type="search" id="search-box" placeholder="search here..." />
        <label for="search-box"><i data-feather="search"></i></label>
      </div>
      <!-- Search Form end -->
    </nav>
    <!-- Navbar End-->

    <!-- About Section Start -->
    <section id="about" class="about">
      <h2>Order Success!</h2>
        <h3>Order ID: <?php echo e($order->id); ?></h3>
        <h3>Total Amount: IDR <?php echo e(number_format($totalAmount, 2)); ?></h3><br/>
        <h3>Order Details:</h3>
        <table class="table custom-table">
            <thead>
                <tr>
                    <th>Gambar</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $order->detailPesanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailPesanan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td style="width: 150px"><img src="<?php echo e(asset('img/' . $detailPesanan->product->gambar)); ?>" alt="<?php echo e($detailPesanan->product->nama); ?>" style="width: 100%;" class="menu-card-img" /></td>
                        <td><?php echo e($detailPesanan->product->nama); ?></td>
                        <td>IDR <?php echo e(number_format($detailPesanan->product->harga, 2)); ?></td>
                        <td><?php echo e($detailPesanan->jumlah); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>


    <!-- Footer Section start -->
    <footer>
      <div class="socials">
        <a href="#"><i data-feather="instagram"></i></a>
        <a href="#"><i data-feather="twitter"></i></a>
        <a href="#"><i data-feather="facebook"></i></a>
      </div>

      <div class="links">
        <a href="#">Home</a>
        <a href="#about">Tentang Kami</a>
        <a href="#menu">Menu</a>
        <a href="#contact">Kontak</a>
      </div>

      <div class="credit">
        <p>Created by <a href="">Boys.</a>. | &copy; 2023.</p>
      </div>
    </footer>
    <!-- Footer Section end -->

    <!-- Feather Icons -->
    <script>
      feather.replace();
    </script>

    <!-- My javascirpt -->
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
  </body>
</html><?php /**PATH C:\Users\Katon\Documents\katon\semester 4\web\example-app\example-app\example-app\resources\views/order-success.blade.php ENDPATH**/ ?>