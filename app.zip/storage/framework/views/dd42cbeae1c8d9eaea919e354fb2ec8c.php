<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Kopi Terus</title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,400;0,700;1,700&display=swap"
      rel="stylesheet"
    />

    <!-- Include SweetAlert2 library -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>

    <!-- Feathers Icons -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- My Style -->
    <link rel="stylesheet" href="css/style.css" />
  </head>
  <body>
    <!-- Navbar Start-->
    <nav class="navbar">
      <a href="#" class="navbar-logo">ngopi<span>terus.</span></a>

      <div class="navbar-nav">
        <a href="/#home">Home</a>
        <a href="/#about">Tentang Kami</a>
        <a href="/#menu">Menu</a>
        <a href="/#contact">Kontak</a>
      </div>

      <div class="navbar-extra">
        <a href="<?php echo e(route('search')); ?>" id="search-button"><i data-feather="search"></i></a>
        <a href="<?php echo e(route('cart.show')); ?>" id="shopping-cart"><i data-feather="shopping-cart"></i></a>
        <a href="#" id="hamburger-menu"><i data-feather="menu"></i></a>
      </div>

      <!-- Search Form start -->
      <div class="search-form">
        <input type="search" id="search-box" placeholder="search here..." />
        <label for="search-box"><i data-feather="search"></i></label>
      </div>
      <!-- Search Form end -->
    </nav>
    <!-- Navbar End-->

  <!-- Menu Section Start -->
  <section id="menu" class="menu">
    <!-- ... Konten sebelumnya ... -->

    <div class="row">
        <?php foreach ($produks as $product) { ?>
          <div class="menu-card">
            <img src="img/<?php echo $product['gambar']; ?>" alt="<?php echo $product['nama']; ?>" class="menu-card-img" />
            <h3 class="menu-card-title"><?php echo $product['nama']; ?></h3>
            <p class="menu-card-price">IDR <?php echo $product['harga']; ?></p>
            <!-- Add to Cart Button -->
            <form action="/add-to-cart" method="post">
              <!-- Add the CSRF token -->
              <?php echo csrf_field(); ?>
              <!-- You can use a hidden input field to store the product ID or any other data needed -->
              <input type="hidden" name="id" value="<?php echo $product['id']; ?>" />
              <input type="hidden" name="nama" value="<?php echo $product['nama']; ?>" />
              <input type="hidden" name="harga" value="<?php echo $product['harga']; ?>" />
              <input type="hidden" name="gambar" value="<?php echo $product['gambar']; ?>" />
              <!-- Add an input field for quantity -->
              <div class="input-group">
                  <label for="quantity-<?php echo $product['id']; ?>">Quantity:</label>
                  <input type="number" id="quantity-<?php echo $product['id']; ?>" name="quantity" value="1" min="1" style="padding: 5px; border-radius: 5px; width: 50px;">
              </div>
              <button type="submit" class="btn" style="padding: 5px; border-radius: 5px; width: 100px; margin-top: 20px;">Add to Cart</button>
            </form>
          </div>
        <?php } ?>
      </div>
    </section>


    <!-- Menu Section End -->

    <script>
        // Check if there's a success message in the session (set in the controller after successful form submission)
        const successMessage = "<?php echo e(session('success')); ?>";

        // If the success message is present, show the SweetAlert popup
        if (successMessage) {
          Swal.fire({
            title: "Success!",
            text: successMessage,
            icon: "success",
            confirmButtonText: "OK",
          });
        }
      </script>

    <!-- Footer Section start -->
    <footer>
        <div class="socials">
          <a href="#"><i data-feather="instagram"></i></a>
          <a href="#"><i data-feather="twitter"></i></a>
          <a href="#"><i data-feather="facebook"></i></a>
        </div>

        <div class="links">
          <a href="#">Home</a>
          <a href="#about">Tentang Kami</a>
          <a href="#menu">Menu</a>
          <a href="#contact">Kontak</a>
        </div>

        <div class="credit">
          <p>Created by <a href="">Boys.</a>. | &copy; 2023.</p>
        </div>
      </footer>
      <!-- Footer Section end -->

      <!-- Feather Icons -->
      <script>
        feather.replace();
      </script>

      <!-- My javascirpt -->
      <script src="js/script.js"></script>
    </body>
  </html>
<?php /**PATH C:\Users\Katon\Documents\katon\semester 4\web\example-app\example-app\example-app\resources\views/menu.blade.php ENDPATH**/ ?>