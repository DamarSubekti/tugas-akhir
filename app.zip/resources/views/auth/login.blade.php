<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,400;0,700;1,700&display=swap" rel="stylesheet">
    <!-- Include SweetAlert2 library -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.18/dist/sweetalert2.all.min.js"></script>

    <!-- Feathers Icons -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- My Style -->
    <link rel="stylesheet" href="css/style.css" />
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-image: url('img/header-bg.jpg');
            background-size: cover;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            color: #111111;
        }

        h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: bold;
            margin-bottom: 5px;
            color: #111111;
        }

        input[type="email"],
        input[type="password"] {
            padding: 10px;
            border: 1px solid #1b1b1b;
            border-radius: 5px;
            margin-bottom: 10px;
        }

        button {
            padding: 10px;
            background-color: #ff6b6b;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button:hover {
            background-color: #ff4f4f;
        }
    </style>
</head>
<body>

    <!-- Navbar Start-->
    <nav class="navbar">
        <a href="#" class="navbar-logo">ngopi<span>terus.</span></a>

        <div class="navbar-nav">
          <a href="/#home">Home</a>
          <a href="/#about">Tentang Kami</a>
          <a href="/#menu">Menu</a>
          <a href="/#contact">Kontak</a>
        </div>

        <div class="navbar-extra">
          <a href="{{ route('search') }}" id="search-button"><i data-feather="search"></i></a>
          <a href="{{ route('cart.show') }}" id="shopping-cart"><i data-feather="shopping-cart"></i></a>
          <a href="#" id="hamburger-menu"><i data-feather="menu"></i></a>
        </div>
    </nav>

    <section class="login" id="login">
    <div class="container">
        <h2>Login</h2>

        @if($errors->has('login_failed'))
            <p style="color: red;">{{ $errors->first('login_failed') }}</p>
        @endif

        <form method="POST" action="{{ route('login.post') }}">
            @csrf

            <label for="email">Email</label>
            <input type="email" name="email" id="email" value="{{ old('email') }}" required>

            <label for="password">Password</label>
            <input type="password" name="password" id="password" required>

            <button type="submit">Login</button>
        </form>

        <p>Don't have an account? <a href="{{ route('register') }}">Register here</a>.</p>
    </div>
    </section>

</body>
</html>
