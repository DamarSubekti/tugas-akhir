<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pesanan;
use App\Models\DetailPesanan;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;

class CartController extends Controller
{
    /**
     * Add a product to the cart.
     */
    public function addToCart(Request $request)
    {
        $id = $request->input('id');
        $nama = $request->input('nama');
        $harga = $request->input('harga');
        $gambar = $request->input('gambar');
        $quantity = $request->input('quantity');

        // Get the cart data from the session
        $cart = session()->get('cart', []);

        // If the product is already in the cart, increment the quantity
        if (isset($cart[$id])) {
            $cart[$id]['jumlah']++;
        } else {
            // If the product is not in the cart, add it as a new item
            $cart[$id] = [
                'id' => $id,
                'nama' => $nama,
                'harga' => $harga,
                'gambar' => $gambar,
                'jumlah' => $quantity,
            ];
        }

        session()->put('cart', $cart);

        return redirect()->back()->with('success', 'Product added to cart successfully!');
    }

    /**
     * Display the cart contents.
     */
    public function showCart()
    {
        // Get the cart data from the session
        $cart = session()->get('cart', []);

        return view('cart', compact('cart'));
    }

    public function submitOrder(Request $request)
    {
        // Start the database transaction
        DB::beginTransaction();

        try {
            // Create a new order (pesanan) in the database
            $pesanan = new Pesanan();
            $pesanan->nama = $request->input('namaOrang');
            $pesanan->notelp = $request->input('notelp');
            $pesanan->jumlah = 0; // Set the initial jumlah to 0
            $pesanan->date = now(); // Set the current time to the 'date' field
            $pesanan->save();

            // Get the cart data from the session and insert it into the detail_pesanan table
            $cart = Session::get('cart', []);
            $totalAmount = 0;

            foreach ($cart as $productId => $product) {
                $detailPesanan = new DetailPesanan();
                $detailPesanan->pesananid = $pesanan->id;
                $detailPesanan->produkid = $product['id'];
                $detailPesanan->jumlah = $product['jumlah'];
                $detailPesanan->save();

                // Calculate the total amount for the order
                $totalAmount += ($product['harga'] * $product['jumlah']);
            }

            // Update the jumlah in the Pesanan model with the correct totalAmount
            $pesanan->jumlah = $totalAmount;
            $pesanan->save();

            // Commit the database transaction
            DB::commit();

            // Clear the cart after the successful order submission
            Session::forget('cart');

            // Redirect to the order success page with the order ID and total amount
            return Redirect::route('order.success', ['orderId' => $pesanan->id, 'totalAmount' => $totalAmount]);

        } catch (\Exception $e) {
            // Rollback the database transaction in case of an error
            DB::rollback();

            // Optionally, you can add an error message to the session and redirect back to the cart page
            Session::flash('error', 'Error occurred while submitting the order. Please try again.');
            return redirect()->back();
        }
    }

    public function orderSuccess($orderId, $totalAmount)
    {
        // Fetch the order details and related products using the $orderId
        $order = Pesanan::with('detailPesanan.product')->find($orderId);

        // Return the order success view with the order details and total amount
        return view('order-success', compact('order', 'totalAmount'));
    }
}
