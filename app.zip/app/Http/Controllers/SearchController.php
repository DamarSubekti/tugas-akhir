<?php

namespace App\Http\Controllers;

use App\Models\Produk;
use Illuminate\Http\Request;

class SearchController extends Controller
{
     public function index(Request $request)
    {
        // Get the search query from the request
        $query = $request->input('query');

        // Search for products that match the query in the 'nama' column
        $produks = Produk::where('nama', 'like', '%' . $query . '%')->get();

        // Return the view with the search results
        return view('search', compact('produks'));
    }
}

