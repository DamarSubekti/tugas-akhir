<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Produk;

class DashboardController extends Controller
{
    public function index()
    {
        // Retrieve all data from the Produk model
        $produks = Produk::all();

        // Pass the data to the view and return the view
        return view('welcome', compact('produks'));
    }
}
