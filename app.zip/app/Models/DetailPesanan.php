<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DetailPesanan extends Model
{
   use HasFactory;

    protected $table = 'detailpesanan'; 
    protected $primaryKey = 'id'; 
    protected $fillable = ['produkid', 'jumlah', 'pesananid'];

    public $timestamps = false; // Add this line to disable the timestamps

    // Define the relationship with Produk model
    public function product()
    {
        return $this->belongsTo(Produk::class, 'produkid', 'id');
    }
}
